// Listas para almacenar datos de hoteles y personalizaciones
const players = []; 
const teams = []; 

// Lista de tipos de habitaciones
const positions = [
    "Basica",
    "Suite",
    "Ejecutiva",
    "Habitacion cama King",
    "Habitacion cama Sencilla",
    "Deluxe"
];

// Carga los tipos de habitacion en el formulario
function loadPositions() {
    const positionSelect = document.getElementById("playerPosition"); // Obtiene el elemento select para los tipos de habitacion
    positionSelect.innerHTML = `<option value="">Seleccione Tipo de Habitación</option>`; // Agrega la opción predeterminada
    positions.forEach(position => {
        const option = document.createElement("option"); // Crea un elemento de opción
        option.value = position; // Establece el valor de la opción
        option.textContent = position; // Establece el texto visible de la opción
        positionSelect.appendChild(option); // Agrega la opción al selector
    });
}

// Carga los hoteles en el selector del formulario de personalización
function updateTeamSelect() {
    const teamSelect = document.getElementById("playerTeam"); // Obtiene el elemento select para los hoteles
    teamSelect.innerHTML = `<option value="">Seleccione Hotel</option>`; // Agrega la opción predeterminada
    teams.forEach(team => {
        const option = document.createElement("option"); // Crea un elemento de opción
        option.value = team.name; // Establece el valor de la opción como el nombre del hotel
        option.textContent = team.name; // Establece el texto visible como el nombre del hotel
        teamSelect.appendChild(option); // Agrega la opción al selector
    });
}

// Maneja el formulario para agregar hoteles
const teamForm = document.getElementById("addTeamForm"); // Obtiene el formulario para agregar hoteles
teamForm.addEventListener("submit", e => {
    e.preventDefault(); // Evita el envío predeterminado del formulario
    const name = document.getElementById("teamName").value; // Obtiene el nombre del hotel
    const logoFile = document.getElementById("teamLogo").files[0]; // Obtiene el archivo del logo
    const logo = logoFile ? URL.createObjectURL(logoFile) : "assets/images/default-team.jpg"; // Genera la URL del logo o usa una imagen predeterminada

    if (!name) {
        alert("Por favor, ingrese el nombre del equipo."); // Muestra un mensaje si el nombre está vacío
        return; // Finaliza la ejecución
    }

    const team = { name, logo }; // Crea un objeto hotel
    teams.push(team); // Agrega el hotel a la lista de hoteles
    updateTeamCards(); // Actualiza las tarjetas de hoteles
    updateTeamSelect(); // Actualiza el selector de hoteles
    teamForm.reset(); // Resetea el formulario
});

// Actualiza la visualización de los hoteles
function updateTeamCards() {
    const teamContainer = document.getElementById("teamCardsContainer"); // Obtiene el contenedor de tarjetas de hoteles
    teamContainer.innerHTML = ""; // Limpia el contenido existente
    teams.forEach(team => {
        const card = `<div class="team-card">
            <img src="${team.logo}" alt="${team.name}" style="width: 100px; height: 100px; border-radius: 50%;"> <!-- Imagen del logo del equipo -->
            <h3>${team.name}</h3> <!-- Nombre del equipo -->
        </div>`;
        teamContainer.innerHTML += card; // Agrega la tarjeta al contenedor
    });
}

// Maneja el formulario para agregar personalizaciones de hotel
const playerForm = document.getElementById("addPlayerForm"); // Obtiene el formulario para agregar jugadores
playerForm.addEventListener("submit", e => {
    e.preventDefault(); // Evita el envío predeterminado del formulario
    const name = document.getElementById("playerName").value; // Obtiene el nombre del jugador
    const age = document.getElementById("playerAge").value; // Obtiene la edad del jugador
    const position = document.getElementById("playerPosition").value; // Obtiene la posición se  leccionada
    const team = document.getElementById("playerTeam").value; // Obtiene el equipo seleccionado

    if (!name || !age || !position || !team) {
        alert("Por favor, complete todos los campos obligatorios."); // Muestra un mensaje si falta algún campo obligatorio
        return; // Finaliza la ejecución
    }

    const player = { name, age, position, team, }; // Crea un objeto jugador
    players.push(player); // Agrega el jugador a la lista de jugadores
    updatePlayerTable(); // Actualiza la tabla de jugadores
    playerForm.reset(); // Resetea el formulario
});

// Actualiza la tabla de jugadores
function updatePlayerTable() {
    const playerTable = document.getElementById("playerTableBody"); // Obtiene el cuerpo de la tabla de jugadores
    playerTable.innerHTML = ""; // Limpia el contenido existente
    players.forEach(player => {
        const row = `<tr>
            <td>${player.name}</td> <!-- Nombre del jugador -->
            <td>${player.age}</td> <!-- Edad del jugador -->
            <td>${player.position}</td> <!-- Posición del jugador -->
            <td>${player.team}</td> <!-- Equipo del jugador -->
        </tr>`;
        playerTable.innerHTML += row; // Agrega la fila a la tabla
    });
}

// Inicializa el sistema al cargar la página
document.addEventListener("DOMContentLoaded", () => {
    loadPositions(); // Carga las posiciones en el selector
    updateTeamSelect(); // Carga los equipos en el selector
});
